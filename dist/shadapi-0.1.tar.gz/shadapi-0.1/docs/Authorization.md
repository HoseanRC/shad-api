# ثبت نام و ورود

<p align="center">
    <a href="https://github.com/HoseanRC/shad-api/blob/master/docs/Handling-Updates.md">
        صفحه بعدی
    </a>
  •
  <a href="https://github.com/HoseanRC/shad-api/blob/master/docs/Project-Setup.md">
        صفحه قبلی
    </a>
</p>
